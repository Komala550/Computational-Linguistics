PROBLEM 1
_____________________________

The named entity recognition done manually are marked in the website and the outputs are in manual_outputs.txt file


PROBLEM 2
_____________________________

The models are trained on 20% dataset given.It was not trained on whole dataset because it's taking 6 hrs to run on whole dataset which unaffordable on Googles GPU.

The models were in two different notebooks for the same reason.

***BERT MODEL****

Training bert model on namapadam corpus is in Makefile_bert.ipynb

And the training,test and validation macro-F1 scores on the respective sets are reported in Makefile_bert.ipynb for bert model

***NER MODEL****

Training ner model on namapadam corpus is in Makefile_ner.ipynb

And the training,test and validation macro-F1 scores on the respective sets are reported in Makefile_ner.ipynb for bert model

***COMPARISION***

The comparision of both models on macro-F1 scores is done in  Makefile_ner.ipynb


PROBLEM 3
_____________________________

The named entity recognition outputs given by chatgpt are in chatgpt_outputs.txt file

PROBLEM 4
_____________________________


Question 2(BERT) vs Question 1(BERT) as ground truth
precision,recall,macro-F1 scores are calculated in Makefile_bert.ipynb

Question 3(BERT) vs Question 1(BERT) as ground truth
precision,recall,macro-F1 scores are calculated in Makefile_bert.ipynb

Question 3 vs Question 1 as ground truth
precision,recall,macro-F1 scores are calculated in Makefile_bert.ipynb

Question 2(NER) vs Question 1(NER) as ground truth
precision,recall,macro-F1 scores are calculated in Makefile_ner.ipynb

Question 3(NER) vs Question 1(NER) as ground truth
precision,recall,macro-F1 scores are calculated in Makefile_ner.ipynb

PROBLEM 5
_____________________________

The answer for problem 5 is in Makefile_ner.ipynb

NOTE
_____________________________

The notebooks should be run in Google Colab
The files:
   25sentences.txt
   manual_outputs.txt
   chatgpt_outputs.txt
should be unploaded to while running notebooks

REFERENCES
_____________________________

https://huggingface.co/ai4bharat/IndicNER
https://stackoverflow.com/
https://chat.openai.com/

















