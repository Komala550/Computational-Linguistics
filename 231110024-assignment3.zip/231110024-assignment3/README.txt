**The MAKEFILE.ipynb should be run in google Colab only**

These files should be uploaded to run:
--------------------------------------
test.te
test200.te

test.en
test200.en-Contains 200 english sentences ground truth for chatgpt

test.hi
test200.hi

en_te.chatgpt
te_hi.chatgpt
hi_te.chatgpt
te_en.chatgpt

Files_Description:
------------------
test.te-Original benchmark telugu file
tests.te-Contains 1000 telugu sentences
test200.te-Contains 200 telugu sentences ground truth for chatgpt

test.en-Original benchmark english file
tests.en-Contains 1000 english sentences
test200.en-Contains 200 english sentences ground truth for chatgpt

test.hi-Original benchmark hindi file
tests.hi-Contains 1000 hindi sentences
test200.hi-Contains 200 hindi sentences ground truth for chatgpt

en_te.nllb-translated from english to telugu through nllb model
te_hi.nllb-translated from telugu to hindi through nllb model
hi_te.nllb-translated from hindi to telugu through nllb model
te_en.nllb-translated from telugu to english through nllb model

en_te.indictrans-translated from english to telugu through indictrans model
te_hi.indictrans-translated from telugu to hindi through indictrans model
hi_te.indictrans-translated from hindi to telugu through indictrans model
te_en.indictrans-translated from telugu to english through indictrans model

en_te.chatgpt- Translated from English to Telugu through ChatGPT.
te_hi.chatgpt- Translated from Telugu to Hindi through ChatGPT.
hi_te.chatgpt- Translated from Hindi to Telugu through ChatGPT.
te_en.chatgpt- Translated from Telugu to English through ChatGPT.


Random sentences:
-----------------
In the MAKEFILE,code is written to generate files with 1000 random sentences

Problem1:
----------
1.nllb model:Run the cells under nllb.

2.There is a cell named RESTART SESSION.Restart session there.

3.indictrans model:Run the cells under indictrans.

Problem2:
----------
bleu and rouge scores are calculated for every pair for every model in the cells below problem 3.

Problem3:
----------
Problem 3 is answered in notebook only.






